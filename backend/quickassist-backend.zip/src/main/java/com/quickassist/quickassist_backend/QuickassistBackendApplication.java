package com.quickassist.quickassist_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuickassistBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuickassistBackendApplication.class, args);
	}

}
