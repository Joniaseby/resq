package com.quickassist.quickassist_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickassistBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
